//var io = require('sails.io.js')( require('socket.io-client') );

 // var socketIOClient = require('socket.io-client');
 // var sailsIOClient = require('sails.io.js');


module.exports = {


  friendlyName: 'Create socket',


  description: '',


  inputs: {

  },


  exits: {

  },


  fn: async function (inputs) {
   
  // io.sails.url = "http://localhost:1337";
    // var newSailsSocket = io.socket.isConnected();
    // console.log(newSailsSocket);
}

};
