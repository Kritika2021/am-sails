/**
 * Admin.js
 *
 * @description :: A model definition represents a database table/collection.
 * @docs        :: https://sailsjs.com/docs/concepts/models-and-orm/models
 */

module.exports = {

  attributes: {

    //  ╔═╗╦═╗╦╔╦╗╦╔╦╗╦╦  ╦╔═╗╔═╗
    //  ╠═╝╠╦╝║║║║║ ║ ║╚╗╔╝║╣ ╚═╗
    //  ╩  ╩╚═╩╩ ╩╩ ╩ ╩ ╚╝ ╚═╝╚═╝
    
    username:{
      type:'string'
    },
    email_id:{
      type:'string'
    },
    mobile_number:{
      type:'string'
    },
    admin_type:{
      type: 'string',
      isIn: [ 'ADMIN', 'SUPER ADMIN' ]
    },
    is_deleted:{
      type:'boolean', defaultsTo:false
    },
    deleted_on:{
      type:'ref',
      columnType: 'datetime'
    },
    password:{
      type:'string'
    },
    profile_pic:{
      type:'string'
    },
    full_name:{
      type:'string'
    },
    fcm_token:{
      type:'string'
    },
    createdAt: { type: 'ref', columnType: 'datetime', autoCreatedAt: true, },
    updatedAt: { type: 'ref' , columnType: 'datetime', autoUpdatedAt: true, },
   

  
    //  ╔═╗╔╦╗╔╗ ╔═╗╔╦╗╔═╗
    //  ║╣ ║║║╠╩╗║╣  ║║╚═╗
    //  ╚═╝╩ ╩╚═╝╚═╝═╩╝╚═╝


    //  ╔═╗╔═╗╔═╗╔═╗╔═╗╦╔═╗╔╦╗╦╔═╗╔╗╔╔═╗
    //  ╠═╣╚═╗╚═╗║ ║║  ║╠═╣ ║ ║║ ║║║║╚═╗
    //  ╩ ╩╚═╝╚═╝╚═╝╚═╝╩╩ ╩ ╩ ╩╚═╝╝╚╝╚═╝

  },

};

